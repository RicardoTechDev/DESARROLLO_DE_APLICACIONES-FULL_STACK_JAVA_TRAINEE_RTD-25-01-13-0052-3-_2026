package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.ConexionBD;
import model.Libro;

public class LibroDAO {
	//CRUD
	
	
	//READ
	//Obtiene todos los libros
	public List<Libro> listarTodos(){
		List<Libro> libros = new ArrayList<>();
		
		String sql = 
				"""
				SELECT 
					id, 
					titulo, 
					autor, 
					isbn, 
					disponible 
				FROM libros 
				ORDER BY autor 
				""";
		
		try (
				Connection conexion = ConexionBD.getInstancia().getConexion();
				PreparedStatement statement = conexion.prepareStatement(sql);
				ResultSet resultSet = statement.executeQuery();
				
				){
				while(resultSet.next()) {
					Libro libro = new Libro(
							resultSet.getInt("id"), 
							resultSet.getString("titulo"),
							resultSet.getString("autor"),
							resultSet.getString("isbn"),
							resultSet.getBoolean("disponible"));
					
					libros.add(libro);
				}
		}catch(SQLException e) {
			System.out.println(e);
		}
		
		return libros;
	}
	

	//Obtiene todos los libros filtrados por título y/o autor
		public List<Libro> buscar(String texto){
			List<Libro> libros = new ArrayList<>();
			
			String sql = 
					"""
					SELECT 
						id, 
						titulo, 
						autor, 
						isbn, 
						disponible 
					FROM libros
					WHERE LOWER(titulo) LIKE ? OR LOWER(autor) LIKE ? 
					ORDER BY autor 
					""";
			
			try (
					Connection conexion = ConexionBD.getInstancia().getConexion();
					PreparedStatement statement = conexion.prepareStatement(sql);
					){
					String filtro = "%" + texto.toLowerCase() + "%";
					statement.setString(1, filtro);
					statement.setString(2, filtro);
					
					
					try(ResultSet resultSet = statement.executeQuery();){
						while(resultSet.next()) {
							Libro libro = new Libro(
									resultSet.getInt("id"), 
									resultSet.getString("titulo"),
									resultSet.getString("autor"),
									resultSet.getString("isbn"),
									resultSet.getBoolean("disponible"));
							
							libros.add(libro);
							}
						
					}catch(SQLException e) {
						System.out.println("Error al consultar la base de datos" + e);
					}
			}catch(SQLException e) {
				System.out.println("Error l consultar la base de datos" + e);
			}
			
			return libros;
		}

		
		//Inserta un nuevo registro
		public boolean insertar(Libro libro){		
			String sql = 
					"""
					INSERT INTO libros
					(
						titulo, 
						autor, 
						isbn, 
						disponible
					)
					VALUES(?, ?, ?, ?) 
					""";
			
			try (
					Connection conexion = ConexionBD.getInstancia().getConexion();
					PreparedStatement statement = conexion.prepareStatement(sql);
					){
					
					statement.setString(1, libro.getTitulo());
					statement.setString(2, libro.getAutor());
					statement.setString(3, libro.getIsbn());
					statement.setBoolean(4, libro.isDisponible());
					
					      // 1 > 0 --> return true o 0 > 0 --> return false
					return statement.executeUpdate() > 0;
					
			}catch(SQLException e) {
				System.out.println("Error l consultar la base de datos" + e);
				
				return false; 
			}
			
		}
		
		
		//Actualización de un libro
		public boolean actualizar(Libro libro){		
			String sql = 
					"""
					UPDATE libros
					SET
						titulo = ?, 
						autor = ?, 
						isbn = ?, 
						disponible = ?
					
					WHERE id = ?
					""";
			
			try (
					Connection conexion = ConexionBD.getInstancia().getConexion();
					PreparedStatement statement = conexion.prepareStatement(sql);
					){
					
					statement.setString(1, libro.getTitulo());
					statement.setString(2, libro.getAutor());
					statement.setString(3, libro.getIsbn());
					statement.setBoolean(4, libro.isDisponible());
					statement.setInt(5, libro.getId());
					
					      // 1 > 0 --> return true o 0 > 0 --> return false
					return statement.executeUpdate() > 0;
					
			}catch(SQLException e) {
				System.out.println("Error l consultar la base de datos" + e);
				
				return false; 
			}
			
		}
		
		//Eliminación de un libro
		public boolean eliminar(int id){		
			String sql = 
					"""
					DELETE FROM libros 
					WHERE id = ?
					""";
			
			try (
					Connection conexion = ConexionBD.getInstancia().getConexion();
					PreparedStatement statement = conexion.prepareStatement(sql);
					){
					
					statement.setInt(1, id);
					
					      // 1 > 0 --> return true o 0 > 0 --> return false
					return statement.executeUpdate() > 0;
					
			}catch(SQLException e) {
				System.out.println("Error l consultar la base de datos" + e);
				
				return false; 
			}
			
		}
		
		
	     
	    //Busca un libro por ID 
	    public Libro buscarPorId(int id) {
	        String sql =
	                """
	                SELECT *
	                FROM libros
	                WHERE id = ?
	                """;

	        try (
	            Connection conexion = ConexionBD.getInstancia().getConexion();
	            PreparedStatement statement = conexion.prepareStatement(sql)
	        ) {

	            statement.setInt(1,id);

	            try (
	                ResultSet resultado = statement.executeQuery()
	            ) {

	                if (resultado.next()) {
	                    return new Libro(
	                        resultado.getInt("id"),
	                        resultado.getString("titulo"),
	                        resultado.getString("autor"),
	                        resultado.getString("isbn"),
	                        resultado.getBoolean("disponible")
	                    );
	                }
	            }


	        } catch (SQLException e) {

	            e.printStackTrace();
	        }


	        return null;
	    }

}
