package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.ConexionBD;
import model.Libro;
import model.Usuario;

public class UsuarioDAO {

	
	//Busca un usuario por el correo y contraseña
	public Usuario autenticar(String correo, String password) {
		
		String sql = 
				"""
				SELECT 
					id, 
					nombre, 
					correo, 
					rol  
				FROM usuarios
				WHERE correo = ? AND password = ? 
				""";
		
		try (
				Connection conexion = ConexionBD.getInstancia().getConexion();
				PreparedStatement statement = conexion.prepareStatement(sql);				
				){
					statement.setString(1, correo);
					statement.setString(2, password);
					
					try(ResultSet resultSet = statement.executeQuery();){
						if (resultSet.next()) {
							Usuario usuario = new Usuario(
															resultSet.getInt("id"),
															resultSet.getString("nombre"),
															resultSet.getString("correo"),
															resultSet.getString("rol")
															);
							return usuario;
						}
						
					}catch(SQLException e) {
						System.out.println("Error al consultar la base de datos" + e);
					}
				}catch(SQLException e) {
					System.out.println("Error al consultar la base de datos" + e);
				}
	   
		return null;
	}
}
