package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.time.LocalDate;

import java.util.ArrayList;
import java.util.List;

import dto.PrestamoDTO;
import util.ConexionBD;


/**
 * DAO encargado de las operaciones
 * relacionadas con préstamos.
 */
public class PrestamoDAO {


    /*
     * =====================================================
     * CREATE
     * =====================================================
     *
     * Crea un nuevo préstamo.
     */
    public boolean prestar(
            int usuarioId,
            int libroId) {


        Connection conexion = null;


        try {


            conexion =
                    ConexionBD
                    .getInstancia()
                    .getConexion();


            /*
             * Desactivamos el commit automático.
             *
             * Necesitamos que:
             *
             * 1. libro pase a no disponible
             * 2. se inserte el préstamo
             *
             * ocurran como una sola operación.
             */
            conexion.setAutoCommit(false);


            /*
             * ==========================================
             * 1. INTENTAR RESERVAR EL LIBRO
             * ==========================================
             */

            String sqlLibro =
                    """
                    UPDATE libros

                    SET disponible = FALSE

                    WHERE id = ?
                      AND disponible = TRUE
                    """;


            try (

                PreparedStatement statement =
                    conexion.prepareStatement(
                            sqlLibro
                    )

            ) {


                statement.setInt(
                        1,
                        libroId
                );


                int filas =
                        statement.executeUpdate();


                /*
                 * Si no modificamos ninguna fila,
                 * significa que el libro:
                 *
                 * - no existe
                 * o
                 * - ya estaba prestado.
                 */
                if (filas == 0) {


                    conexion.rollback();


                    return false;
                }
            }


            /*
             * ==========================================
             * 2. INSERTAR EL PRÉSTAMO
             * ==========================================
             */

            String sqlPrestamo =
                    """
                    INSERT INTO prestamos
                    (
                        usuario_id,
                        libro_id,
                        fecha_prestamo
                    )

                    VALUES (?, ?, ?)
                    """;


            try (

                PreparedStatement statement =
                    conexion.prepareStatement(
                            sqlPrestamo
                    )

            ) {


                statement.setInt(
                        1,
                        usuarioId
                );


                statement.setInt(
                        2,
                        libroId
                );


                statement.setDate(
                        3,
                        Date.valueOf(
                                LocalDate.now()
                        )
                );


                statement.executeUpdate();
            }


            /*
             * Ambas operaciones funcionaron.
             */
            conexion.commit();


            return true;


        } catch (SQLException e) {


            /*
             * Si ocurre cualquier error,
             * deshacemos todo.
             */
            try {


                if (conexion != null) {


                    conexion.rollback();
                }


            } catch (SQLException rollbackError) {


                rollbackError.printStackTrace();
            }


            e.printStackTrace();


            return false;


        } finally {


            if (conexion != null) {


                try {


                    conexion.setAutoCommit(
                            true
                    );


                    conexion.close();


                } catch (SQLException e) {


                    e.printStackTrace();
                }
            }
        }
    }


    /*
     * =====================================================
     * READ
     * =====================================================
     *
     * Lista los préstamos realizados
     * por un usuario.
     */
    public List<PrestamoDTO> listarPorUsuario(
            int usuarioId) {


        List<PrestamoDTO> prestamos =
                new ArrayList<>();


        String sql =
                """
                SELECT

                    p.id,

                    p.libro_id,

                    l.titulo,

                    p.fecha_prestamo,

                    p.fecha_devolucion,


                    CASE

                        WHEN p.fecha_devolucion IS NULL
                            THEN 'PRESTADO'

                        ELSE
                            'DEVUELTO'

                    END AS estado


                FROM prestamos p


                INNER JOIN libros l

                    ON p.libro_id = l.id


                WHERE p.usuario_id = ?


                ORDER BY p.id DESC
                """;


        try (

            Connection conexion =
                    ConexionBD
                    .getInstancia()
                    .getConexion();


            PreparedStatement statement =
                    conexion.prepareStatement(sql)

        ) {


            statement.setInt(
                    1,
                    usuarioId
            );


            try (

                ResultSet resultado =
                        statement.executeQuery()

            ) {


                while (resultado.next()) {


                    /*
                     * fecha_devolucion puede ser NULL.
                     */
                    Date fechaDevolucionSQL =
                            resultado.getDate(
                                    "fecha_devolucion"
                            );


                    LocalDate fechaDevolucion =
                            null;


                    if (
                        fechaDevolucionSQL
                        != null
                    ) {


                        fechaDevolucion =
                                fechaDevolucionSQL
                                .toLocalDate();
                    }


                    PrestamoDTO prestamo =
                            new PrestamoDTO(

                                resultado.getInt(
                                        "id"
                                ),

                                resultado.getInt(
                                        "libro_id"
                                ),

                                resultado.getString(
                                        "titulo"
                                ),

                                resultado.getDate(
                                        "fecha_prestamo"
                                ).toLocalDate(),

                                fechaDevolucion,

                                resultado.getString(
                                        "estado"
                                )
                            );


                    prestamos.add(
                            prestamo
                    );
                }
            }


        } catch (SQLException e) {


            e.printStackTrace();
        }


        return prestamos;
    }


    /*
     * =====================================================
     * UPDATE
     * =====================================================
     *
     * Devuelve un libro.
     */
    public boolean devolver(
            int prestamoId,
            int usuarioId) {


        Connection conexion =
                null;


        try {


            conexion =
                    ConexionBD
                    .getInstancia()
                    .getConexion();


            conexion.setAutoCommit(
                    false
            );


            /*
             * ==========================================
             * 1. BUSCAR EL LIBRO DEL PRÉSTAMO
             * ==========================================
             */

            int libroId;


            String sqlBuscar =
                    """
                    SELECT libro_id

                    FROM prestamos

                    WHERE id = ?
                      AND usuario_id = ?
                      AND fecha_devolucion IS NULL
                    """;


            try (

                PreparedStatement statement =
                    conexion.prepareStatement(
                            sqlBuscar
                    )

            ) {


                statement.setInt(
                        1,
                        prestamoId
                );


                statement.setInt(
                        2,
                        usuarioId
                );


                try (

                    ResultSet resultado =
                        statement.executeQuery()

                ) {


                    if (!resultado.next()) {


                        conexion.rollback();


                        return false;
                    }


                    libroId =
                            resultado.getInt(
                                    "libro_id"
                            );
                }
            }


            /*
             * ==========================================
             * 2. REGISTRAR FECHA DE DEVOLUCIÓN
             * ==========================================
             */

            String sqlPrestamo =
                    """
                    UPDATE prestamos

                    SET fecha_devolucion = ?

                    WHERE id = ?
                      AND usuario_id = ?
                      AND fecha_devolucion IS NULL
                    """;


            try (

                PreparedStatement statement =
                    conexion.prepareStatement(
                            sqlPrestamo
                    )

            ) {


                statement.setDate(
                        1,
                        Date.valueOf(
                                LocalDate.now()
                        )
                );


                statement.setInt(
                        2,
                        prestamoId
                );


                statement.setInt(
                        3,
                        usuarioId
                );


                int filas =
                        statement.executeUpdate();


                if (filas == 0) {


                    conexion.rollback();


                    return false;
                }
            }


            /*
             * ==========================================
             * 3. VOLVER A DISPONIBILIZAR EL LIBRO
             * ==========================================
             */

            String sqlLibro =
                    """
                    UPDATE libros

                    SET disponible = TRUE

                    WHERE id = ?
                    """;


            try (

                PreparedStatement statement =
                    conexion.prepareStatement(
                            sqlLibro
                    )

            ) {


                statement.setInt(
                        1,
                        libroId
                );


                statement.executeUpdate();
            }


            /*
             * Todo funcionó.
             */
            conexion.commit();


            return true;


        } catch (SQLException e) {


            try {


                if (conexion != null) {


                    conexion.rollback();
                }


            } catch (SQLException rollbackError) {


                rollbackError.printStackTrace();
            }


            e.printStackTrace();


            return false;


        } finally {


            if (conexion != null) {


                try {


                    conexion.setAutoCommit(
                            true
                    );


                    conexion.close();


                } catch (SQLException e) {


                    e.printStackTrace();
                }
            }
        }
    }


    /*
     * =====================================================
     * DELETE
     * =====================================================
     *
     * Incluimos el método para completar
     * conceptualmente CRUD.
     *
     * En una biblioteca real normalmente
     * conservaríamos el historial.
     */
    public boolean eliminar(
            int prestamoId) {


        String sql =
                """
                DELETE FROM prestamos
                WHERE id = ?
                """;


        try (

            Connection conexion =
                    ConexionBD
                    .getInstancia()
                    .getConexion();


            PreparedStatement statement =
                    conexion.prepareStatement(sql)

        ) {


            statement.setInt(
                    1,
                    prestamoId
            );


            return statement.executeUpdate()
                    > 0;


        } catch (SQLException e) {


            e.printStackTrace();


            return false;
        }
    }
}