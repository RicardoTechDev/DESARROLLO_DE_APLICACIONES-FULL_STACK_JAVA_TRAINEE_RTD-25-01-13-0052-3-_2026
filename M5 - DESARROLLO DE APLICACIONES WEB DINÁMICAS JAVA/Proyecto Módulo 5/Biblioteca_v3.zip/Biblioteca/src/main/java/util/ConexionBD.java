package util;

// Importamos la clase Connection.
// Esta clase representa una conexión abierta con una base de datos.
import java.sql.Connection;

// DriverManager se encarga de crear la conexión con la base de datos.
import java.sql.DriverManager;

// SQLException permite manejar errores relacionados con la base de datos.
import java.sql.SQLException;


/*
 * Esta clase se encargará de crear conexiones hacia nuestra base de datos MySQL.
 *
 * En vez de repetir los datos de conexión en distintas partes del proyecto,
 * los dejamos todos centralizados en esta clase.
 */
public class ConexionBD {

    /*
     * DATOS NECESARIOS PARA CONECTARNOS A MYSQL
     */

    // URL indica dónde está nuestra base de datos.
    //
    // jdbc:mysql   -> indica que utilizaremos MySQL.
    // localhost    -> significa que MySQL está instalado en nuestro computador.
    // 3306         -> es el puerto que normalmente utiliza MySQL.
    // db_biblioteca -> es el nombre de nuestra base de datos.
    private static final String URL =
            "jdbc:mysql://localhost:3306/db_biblioteca";


    // Usuario que utilizaremos para conectarnos a MySQL.
    private static final String USUARIO = "root";


    // Contraseña del usuario de MySQL.
    // En este ejemplo está vacía.
    private static final String PASSWORD = "";


    /*
     * Esta variable guardará un objeto de la propia clase ConexionBD.
     *
     * La idea es crear solamente una instancia de esta clase
     * y reutilizarla durante la ejecución del programa.
     */
    private static ConexionBD instancia;


    /*
     * CONSTRUCTOR
     *
     * El constructor es private.
     *
     * Eso significa que desde otra clase NO podremos hacer:
     *
     * new ConexionBD();
     *
     * Esto se hace porque queremos controlar nosotros mismos
     * la creación del objeto.
     */
    private ConexionBD() {

        try {

            /*
             * Intentamos cargar el Driver de MySQL.
             *
             * El Driver funciona como un "traductor" que permite que
             * Java pueda comunicarse con MySQL.
             */
            Class.forName("com.mysql.cj.jdbc.Driver");

        } catch (ClassNotFoundException e) {

            /*
             * Si Java no encuentra el Driver de MySQL,
             * mostramos un mensaje de error.
             *
             * Normalmente esto sucede cuando no agregamos correctamente
             * el archivo .jar del conector de MySQL al proyecto.
             */
            System.out.println("Error: La clase no fue encontrada.");
        }
    }


    /*
     * MÉTODO getInstancia()
     *
     * Este método permite obtener el objeto ConexionBD.
     *
     * Primero pregunta:
     *
     * ¿Ya existe una instancia?
     *
     * Si NO existe, la crea.
     * Si ya existe, simplemente devuelve la misma.
     */
    public static ConexionBD getInstancia() {

        // Si todavía no existe el objeto...
        if (instancia == null) {

            // Creamos una nueva instancia.
            instancia = new ConexionBD();
        }

        // Devolvemos la instancia existente.
        return instancia;
    }


    /*
     * MÉTODO getConexion()
     *
     * Este método abre una conexión real hacia MySQL.
     *
     * Devuelve un objeto de tipo Connection.
     */
    public static Connection getConexion() throws SQLException {

        /*
         * DriverManager intenta conectarse utilizando:
         *
         * 1. La URL de la base de datos.
         * 2. El usuario.
         * 3. La contraseña.
         *
         * Si todo está correcto, devuelve una conexión abierta.
         */
        return DriverManager.getConnection(
                URL,
                USUARIO,
                PASSWORD
        );
    }

}