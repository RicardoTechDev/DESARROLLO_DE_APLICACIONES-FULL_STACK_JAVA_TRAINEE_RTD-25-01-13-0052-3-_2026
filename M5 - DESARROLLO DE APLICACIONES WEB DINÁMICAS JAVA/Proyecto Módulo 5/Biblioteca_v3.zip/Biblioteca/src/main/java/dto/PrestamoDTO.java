package dto;

import java.time.LocalDate;


/**
 * Objeto utilizado para transportar
 * la información que necesitamos
 * mostrar en la vista.
 */
public class PrestamoDTO {


    private int id;

    private int libroId;

    private String tituloLibro;

    private LocalDate fechaPrestamo;

    private LocalDate fechaDevolucion;

    /*
     * Este estado NO existe en la BD.
     *
     * Lo calcularemos a partir de:
     *
     * fecha_devolucion
     */
    private String estado;


    public PrestamoDTO(
            int id,
            int libroId,
            String tituloLibro,
            LocalDate fechaPrestamo,
            LocalDate fechaDevolucion,
            String estado) {


        this.id = id;

        this.libroId = libroId;

        this.tituloLibro =
                tituloLibro;

        this.fechaPrestamo =
                fechaPrestamo;

        this.fechaDevolucion =
                fechaDevolucion;

        this.estado =
                estado;
    }


    public int getId() {
        return id;
    }


    public int getLibroId() {
        return libroId;
    }


    public String getTituloLibro() {
        return tituloLibro;
    }


    public LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }


    public LocalDate getFechaDevolucion() {
        return fechaDevolucion;
    }


    public String getEstado() {
        return estado;
    }
}