package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;

import java.util.List;

import dao.LibroDAO;
import model.Libro;


/**
 * Servlet implementation class LibroServlet
 */
@WebServlet("/libros")
public class LibroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /*
     doGet() --> HTTP GET 
      
      1. /libros
      2. /libros?buscar=java
      
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1. Verificar sesión
		/*
		  request.getSession(false)
		  
		  Dame la session existente,
		  pero NO me crees una nueva
		 */
		HttpSession session = request.getSession(false);
		
		if (session == null || session.getAttribute("usuario") == null) {
			//se construye la ruta desde la raíz de la aplicación web, 
			//por lo que suele ser más seguro usar request.getContextPath() + "/index.jsp".
			response.sendRedirect(request.getContextPath() + "/index.jsp");
			return;
		}
		
		//2. recuperamos la acción a realizar
		String accion = request.getParameter("accion");


        if (accion == null) {

            accion = "listar";
        }
        
        //DAO que nos permitira acceder a la tabla libros en la BD
	    LibroDAO libroDao = new LibroDAO(); 
        
        //3. CONTROLAMOS LAS ACCIONES GET
        switch (accion) {
			            case "nuevo": 
			                request.getRequestDispatcher(
			                        "/libro-form.jsp"
			                ).forward(request,response);
			                break;

			            case "editar":
			                int id =
			                        Integer.parseInt(
			                            request.getParameter("id")
			                        );
			
			
			                Libro libro = libroDao.buscarPorId(id);
			
			
			                request.setAttribute(
			                        "libro",
			                        libro
			                );
			
			
			                request.getRequestDispatcher(
			                        "/libro-form.jsp"
			                ).forward(
			                        request,
			                        response
			                );
			                break;


			            default: 
			                String buscar =
			                        request.getParameter(
			                                "buscar"
			                        );
			
			
			                List<Libro> libros;
			
			
			                if (buscar != null && !buscar.isBlank()) {
			                    libros =
			                            libroDao.buscar(
			                                    buscar
			                            );
			                } else {
			                    libros =
			                            libroDao.listarTodos();
			                }
			
			
			                request.setAttribute(
			                        "libros",
			                        libros
			                );
			
			
			                request.setAttribute(
			                        "buscar",
			                        buscar
			                );
			
			
			                request.getRequestDispatcher(
			                        "/libros.jsp"
			                ).forward(
			                        request,
			                        response
			                );
            }
        }

	

	protected void doPost(
	        HttpServletRequest request,
	        HttpServletResponse response)
	        throws ServletException, IOException {

	    // PASO 1: VERIFICAR SESIÓN DEL USUARIO
	    HttpSession session =
	            request.getSession(false);


	    if (session == null
	            || session.getAttribute("usuario") == null) {

	        // Si no existe sesión, volvemos al login
	        response.sendRedirect(
	                request.getContextPath()
	                + "/index.jsp"
	        );

	        return;
	    }

	    // PASO 2: RECUPERAR LA ACCIÓN

	    /*
	     * Este parámetro llegará desde el formulario
	     * de crear / editar libro.
	     *
	     * Ejemplo:
	     *
	     * accion = guardar
	     *
	     * En el formulario de ELIMINAR que ya tienes,
	     * este parámetro NO viene.
	     */
	    String accion =
	            request.getParameter("accion");


	    // DAO que nos permitirá acceder
	    // a la tabla libros en la BD
	    LibroDAO libroDao =
	            new LibroDAO();


	    // PASO 3: GUARDAR LIBRO

	    /*
	     * "guardar" puede representar:
	     *
	     * CREATE → insertar nuevo libro
	     *
	     * UPDATE → actualizar un libro existente
	     */
	    if ("guardar".equals(accion)) {


	        // Recuperamos los datos del formulario

	        String id =
	                request.getParameter("id");


	        String titulo =
	                request.getParameter("titulo");


	        String autor =
	                request.getParameter("autor");


	        String isbn =
	                request.getParameter("isbn");


	        /*
	         * Un checkbox funciona así:
	         *
	         * marcado:
	         * request.getParameter("disponible")
	         * devuelve un valor
	         *
	         * desmarcado:
	         * devuelve null
	         */
	        boolean disponible =
	                request.getParameter("disponible")
	                != null;

	        // CREATE

	        /*
	         * Si no tenemos ID significa que estamos
	         * registrando un libro nuevo.
	         */
	        if (id == null || id.isBlank()) {


	            Libro libro =
	                    new Libro(
	                            0,
	                            titulo,
	                            autor,
	                            isbn,
	                            disponible
	                    );


	            libroDao.insertar(libro);


	        } else {

	            // UPDATE

	            /*
	             * Si tenemos un ID significa que estamos
	             * editando un libro existente.
	             */

	            int idLibro =
	                    Integer.parseInt(id);


	            Libro libro =
	                    new Libro(
	                            idLibro,
	                            titulo,
	                            autor,
	                            isbn,
	                            disponible
	                    );


	            libroDao.actualizar(libro);
	        }


	    } else {

	        // PASO 4: ELIMINAR

	        /*
	         * AQUÍ CONSERVAMOS LA MISMA LÓGICA
	         * QUE YA TENÍAS.
	         *
	         * Tu formulario de papelera solamente envía:
	         *
	         * id
	         *
	         * Como NO envía accion="guardar",
	         * entra automáticamente a este else.
	         */

	        String id =
	                request.getParameter("id");


	        if (id != null) {


	            libroDao.eliminar(
	                    Integer.parseInt(id)
	            );


	        } else {


	            System.out.println(
	                    "No llegó el ID"
	            );
	        }
	    }

	    // PASO 5: REDIRECCIONAR

	    /*
	     * Después del POST redireccionamos nuevamente
	     * hacia el Servlet.
	     *
	     * Esto genera:
	     *
	     * GET /libros
	     *
	     * y ejecuta nuevamente doGet().
	     */
	    response.sendRedirect(
	            request.getContextPath()
	            + "/libros"
	    );
	}
	
}