package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import dao.UsuarioDAO;
import model.Usuario;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	//TODO: Probar que ocurre si lo eliminamos
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Paso 1. Recuperar los párametros del formulario
		String correo = request.getParameter("correo");
		String password = request.getParameter("password");
		
		//System.out.println(correo);
		
		//Paso 2. Validación de campos
		if(correo == null || correo.isBlank() || password == null || password.isBlank()) {
			request.setAttribute("error", "Debe completar todos los campos");
			
			
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			
			return;
		}
		
		//Paso 3: Consultar la base de datos
		UsuarioDAO usuarioDao = new UsuarioDAO();
		Usuario usuario = usuarioDao.autenticar(correo, password); 
		
		//Paso 4: Validar el resultado de la consulta a la base de datos
		if(usuario != null) {
						
			//Paso 5: Crear la sesión
			HttpSession session =  request.getSession();
			session.setAttribute("usuario",usuario);
			
			//redireccionamos
			response.sendRedirect(request.getContextPath()+ "/libros");
			
		}else {
			request.setAttribute("error", "Correo o contraseña incorrectos");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}

		
	}

}
