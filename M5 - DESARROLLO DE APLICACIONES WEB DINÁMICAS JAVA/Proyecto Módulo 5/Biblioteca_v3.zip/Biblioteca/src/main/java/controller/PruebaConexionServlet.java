package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import util.ConexionBD;

@WebServlet("/probar-conexion")
public class PruebaConexionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        // Carga la instancia Singleton para registrar el Driver JDBC
        ConexionBD.getInstancia();

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html><head><title>Prueba Conexión BD</title></head><body>");
            
            try (Connection conn = ConexionBD.getConexion()) {
                if (conn != null && !conn.isClosed()) {
                    out.println("<h2 style='color:green;'>¡Conexión exitosa a MySQL!</h2>");
                    out.println("<p>Base de datos actual: " + conn.getCatalog() + "</p>");
                } else {
                    out.println("<h2 style='color:orange;'>La conexión retornó null o está cerrada.</h2>");
                }
            } catch (SQLException e) {
                out.println("<h2 style='color:red;'>Error al intentar conectar:</h2>");
                out.println("<pre>" + e.getMessage() + "</pre>");
                e.printStackTrace();
            }

            out.println("</body></html>");
        }
    }
}