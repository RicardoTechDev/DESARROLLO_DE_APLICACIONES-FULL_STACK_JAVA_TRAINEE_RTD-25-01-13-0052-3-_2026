package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Recuperamos la sessión actual, sin crear una nueva
		HttpSession session = request.getSession(false);
		
		//Si existe una sessión la invaladamos
		if(session != null) {
			session.invalidate();
		}
		
		//Redirigimos hacia el login
		response.sendRedirect(request.getContextPath() + "/index.jsp");
		
	}

	

}
