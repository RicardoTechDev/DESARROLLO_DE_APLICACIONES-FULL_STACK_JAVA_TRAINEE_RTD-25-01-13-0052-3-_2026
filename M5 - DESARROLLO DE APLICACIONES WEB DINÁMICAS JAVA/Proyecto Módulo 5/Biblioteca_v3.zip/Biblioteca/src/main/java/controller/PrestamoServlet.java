package controller;

import java.io.IOException;
import java.util.List;

import dao.PrestamoDAO;

import dto.PrestamoDTO;

import model.Usuario;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/prestamos")
public class PrestamoServlet
        extends HttpServlet {

    private static final long serialVersionUID = 1L;


    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {


        HttpSession session =
                request.getSession(false);


        if (
            session == null
            ||
            session.getAttribute("usuario") == null
        ) {


            response.sendRedirect(
                request.getContextPath()
                + "/index.jsp"
            );


            return;
        }


        Usuario usuario =
                (Usuario)
                session.getAttribute(
                    "usuario"
                );


        PrestamoDAO prestamoDAO =
                new PrestamoDAO();


        List<PrestamoDTO> prestamos =
                prestamoDAO.listarPorUsuario(
                        usuario.getId()
                );


        request.setAttribute(
                "prestamos",
                prestamos
        );


        request.getRequestDispatcher(
                "/prestamos.jsp"
        ).forward(
                request,
                response
        );
    }


    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {


        HttpSession session =
                request.getSession(false);


        if (
            session == null
            ||
            session.getAttribute("usuario") == null
        ) {


            response.sendRedirect(
                request.getContextPath()
                + "/index.jsp"
            );


            return;
        }


        Usuario usuario =
                (Usuario)
                session.getAttribute(
                    "usuario"
                );


        String accion =
                request.getParameter(
                    "accion"
                );


        PrestamoDAO prestamoDAO =
                new PrestamoDAO();


        if ("prestar".equals(accion)) {


            int libroId =
                    Integer.parseInt(
                        request.getParameter(
                            "libroId"
                        )
                    );


            prestamoDAO.prestar(
                    usuario.getId(),
                    libroId
            );


            response.sendRedirect(
                request.getContextPath()
                + "/libros"
            );


            return;
        }


        if ("devolver".equals(accion)) {


            int prestamoId =
                    Integer.parseInt(
                        request.getParameter(
                                "prestamoId"
                        )
                    );


            prestamoDAO.devolver(
                    prestamoId,
                    usuario.getId()
            );
        }


        response.sendRedirect(
                request.getContextPath()
                + "/prestamos"
        );
    }
}