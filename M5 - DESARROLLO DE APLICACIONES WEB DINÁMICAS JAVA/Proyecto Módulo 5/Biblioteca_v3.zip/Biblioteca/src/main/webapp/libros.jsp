<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<%@ taglib prefix="c" uri="jakarta.tags.core" %>   

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Biblioteca Digital UNTEC - Catálogo de libros</title>

<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
	rel="stylesheet"
	integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB"
	crossorigin="anonymous">
	
	
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body>
	<!-- Barra de navegación -->
	<nav class="navbar bg-dark text-bg-dark mb-4" data-bs-theme="dark">
		<div class="container">
			<span class="navbar-brand">Aplicación Java Web</span>
			<div class="d-flex aling-items-center">
				<span class="me-3">
			Hola, 
			<strong>
				<c:out value="${ sessionScope.usuario.nombre }" />
			</strong>
			</span>
			<a
                class="btn btn-outline-light btn-sm"
                href="${pageContext.request.contextPath}/prestamos">

                Mis préstamos

            </a>
			
			<a class="text-info" href="${ pageContext.request.contextPath }/logout">
				<i class="fa-solid fa-right-from-bracket">
				</i>
			</a>
			</div>
		</div>
	</nav>
	
	<div class="container">
		<div class="d-flex justify-content-center">
			<div>
			  	<h3>Catálogo de Libros</h3>
			  	<p class="text-muted">Biblioteca Digital UNTEC<p>
			</div>
			<%--
            Solo el ADMIN puede crear libros.
        --%>

        <c:if
            test="${sessionScope.usuario.rol == 'ADMIN'}">


            <a
                href="${pageContext.request.contextPath}/libros?accion=nuevo"
                class="btn btn-success">

                Nuevo libro

            </a>


        </c:if>
			
		</div>
		
		<form action="${ pageContext.request.contextPath }/libros" method="GET" class="row"> 
			<div class="col-md-6">
				<div class="input-group mb-3">
			  <input 
			  		type="text" 
			  		class="form-control" 
			  		placeholder="Buscar por título o autor" 
			  		name="buscar"
			  		value="<c:out value='${ buscar }'/>"
			  		>
			  <button class="btn btn-outline-secondary" type="submit">Buscar</button>
			</div>
			</div>						
		</form>
		
		<c:if test="${ empty libros }">
			<div class="alert alert-warning" role="alert">
				No se encontraron libros.
			</div>
		</c:if>
		
		<%-- Tabla de libros --%>
		<table class="table table-dark table-striped">
		  <thead>
		    <tr>
		      <th scope="col">ID</th>
		      <th scope="col">Título</th>
		      <th scope="col">Autor</th>
		      <th scope="col">ISB</th>
		      <th scope="col">Estado</th>
		      <th scope="col">Opciones</th>
		    </tr>
		  </thead>
		  <tbody>
	
		   <c:forEach var="libro" items="${ libros }">
				<tr>					
					<td>
						<c:out value="${ libro.id }" />
					</td>
								
					<td>
						<c:out value="${ libro.titulo }" />
					</td>
					
					<td>
						<c:out value="${ libro.autor }" />
					</td>
					<td>
						<c:out value="${ libro.isbn }" />
					</td>
					<td>
						<c:choose>
							<c:when test="${ libro.disponible }">
								<span class="badge text-bg-success small">
									<small>Disponible</small>
								</span>							
							</c:when>
							<c:when test="${ !libro.disponible }">
								<span class="badge text-bg-warning small">
									<small>Prestamo</small>
								</span>							
							</c:when>
							<c:otherwise>
								<span class="badge text-bg-danger">
									Sin Información
								</span>
							</c:otherwise>
						
						</c:choose>
					
					</td>
					<td class="d-flex justify-content-around">
						<%--
                            Opciones ADMIN.
                        --%>

                        <c:if
                            test="${sessionScope.usuario.rol == 'ADMIN'}">


                            <a
                                href="${pageContext.request.contextPath}/libros?accion=editar&id=${libro.id}"
                                class="btn btn-link p-0 border-0">

                               <i class="fa-solid fa-pen-to-square text-warning"></i>

                            </a>
							<form method="POST" action="${pageContext.request.contextPath}/libros">
							<input type="hidden" name="id" value="${ libro.id }">
							<button type="submit" class="btn btn-link p-0 border-0">
								<i class="fa-solid fa-trash text-danger"></i>
							</button>
							</form>
                        </c:if>
						<%--
                            Botón de préstamo.
                        --%>

                        <c:if
                            test="${libro.disponible}">
                            <form
                                action="${pageContext.request.contextPath}/prestamos"
                                method="post"
                                class="d-inline">

                                <input type="hidden" name="accion" value="prestar">
                                <input type="hidden" name="libroId" value="${libro.id}">

                                <button class="btn btn-link p-0 border-0">
                                    <i class="fa-solid fa-user-clock text-info"></i>
                                </button>
                            </form>
                        </c:if>
						
					</td>
				</tr>
				
			</c:forEach>
		   
		   </tbody>
		</table>
		
		
		
		
		
	</div>
	
	
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
		crossorigin="anonymous"></script>
	
</body>
</html>