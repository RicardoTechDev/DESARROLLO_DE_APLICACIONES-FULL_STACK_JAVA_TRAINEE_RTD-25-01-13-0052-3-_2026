<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" %>

<%@ taglib
    prefix="c"
    uri="jakarta.tags.core" %>


<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <title>
        Libro | Biblioteca UNTEC
    </title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

</head>


<body class="bg-light">


<div class="container mt-5">


    <div class="row justify-content-center">


        <div class="col-md-7">


            <div class="card shadow">


                <div class="card-body p-4">


                    <h2 class="mb-4">


                        <c:choose>


                            <c:when
                                test="${empty libro}">

                                Registrar libro

                            </c:when>


                            <c:otherwise>

                                Editar libro

                            </c:otherwise>


                        </c:choose>


                    </h2>


                    <form
                        action="${pageContext.request.contextPath}/libros"
                        method="post">


                        <input
                            type="hidden"
                            name="accion"
                            value="guardar">


                        <%--
                            Si estamos editando,
                            enviamos también el ID.
                        --%>

                        <input
                            type="hidden"
                            name="id"
                            value="${libro.id}">


                        <div class="mb-3">

                            <label class="form-label">
                                Título
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="titulo"
                                value="<c:out value='${libro.titulo}' />"
                                required>

                        </div>


                        <div class="mb-3">

                            <label class="form-label">
                                Autor
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="autor"
                                value="<c:out value='${libro.autor}' />"
                                required>

                        </div>


                        <div class="mb-3">

                            <label class="form-label">
                                ISBN
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="isbn"
                                value="<c:out value='${libro.isbn}' />"
                                required>

                        </div>


                        <div class="form-check mb-4">


                            <input
                                type="checkbox"
                                class="form-check-input"
                                name="disponible"
                                id="disponible"

                                <c:if test="${empty libro || libro.disponible}">
                                    checked
                                </c:if>
                            >


                            <label
                                class="form-check-label"
                                for="disponible">

                                Disponible

                            </label>

                        </div>


                        <button
                            type="submit"
                            class="btn btn-primary">

                            Guardar

                        </button>


                        <a
                            href="${pageContext.request.contextPath}/libros"
                            class="btn btn-secondary">

                            Volver

                        </a>


                    </form>


                </div>

            </div>

        </div>

    </div>

</div>


</body>

</html>