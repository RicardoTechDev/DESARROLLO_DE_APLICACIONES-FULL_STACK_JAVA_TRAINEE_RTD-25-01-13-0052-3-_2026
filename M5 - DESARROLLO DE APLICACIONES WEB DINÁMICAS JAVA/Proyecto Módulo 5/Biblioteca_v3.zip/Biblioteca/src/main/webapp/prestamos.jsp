<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" %>

<%@ taglib
    prefix="c"
    uri="jakarta.tags.core" %>


<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1">


    <title>
        Mis préstamos
    </title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

</head>


<body class="bg-light">


<div class="container mt-5">


    <div class="d-flex justify-content-between mb-4">


        <h1>
            Mis préstamos
        </h1>


        <a
            href="${pageContext.request.contextPath}/libros"
            class="btn btn-secondary">

            Volver al catálogo

        </a>


    </div>



    <c:if test="${empty prestamos}">


        <div class="alert alert-info">

            Actualmente no tienes préstamos.

        </div>


    </c:if>



    <c:if test="${not empty prestamos}">


        <div class="card shadow">


            <div class="card-body">


                <table class="table">


                    <thead>

                        <tr>

                            <th>ID</th>

                            <th>Libro</th>

                            <th>Fecha préstamo</th>

                            <th>Fecha devolución</th>

                            <th>Estado</th>

                            <th>Acción</th>

                        </tr>

                    </thead>


                    <tbody>


                        <c:forEach
                            var="prestamo"
                            items="${prestamos}">


                            <tr>


                                <td>
                                    ${prestamo.id}
                                </td>


                                <td>

                                    <c:out
                                        value="${prestamo.tituloLibro}" />

                                </td>


                                <td>
                                    ${prestamo.fechaPrestamo}
                                </td>


                                <td>


                                    <c:choose>


                                        <c:when
                                            test="${empty prestamo.fechaDevolucion}">

                                            -

                                        </c:when>


                                        <c:otherwise>

                                            ${prestamo.fechaDevolucion}

                                        </c:otherwise>


                                    </c:choose>


                                </td>


                                <td>

                                    ${prestamo.estado}

                                </td>


                                <td>


                                    <c:if
                                        test="${prestamo.estado == 'PRESTADO'}">


                                        <form
                                            action="${pageContext.request.contextPath}/prestamos"
                                            method="post">


                                            <input
                                                type="hidden"
                                                name="accion"
                                                value="devolver">


                                            <input
                                                type="hidden"
                                                name="prestamoId"
                                                value="${prestamo.id}">


                                            <button
                                                class="btn btn-success btn-sm">

                                                Devolver

                                            </button>


                                        </form>


                                    </c:if>


                                </td>


                            </tr>


                        </c:forEach>


                    </tbody>


                </table>


            </div>

        </div>


    </c:if>


</div>


</body>

</html>